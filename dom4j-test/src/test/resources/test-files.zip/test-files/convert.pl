#!/usr/bin/perl -w

use strict;

my ($input_file, $from_encoding) = @ARGV;

$input_file =~ /\..*$/;
my $file_extension = $&;

die "Input File Required" unless defined($input_file);
die "Input Encoding Required" unless defined($from_encoding);

my @encodings = qw(UTF16 UTF16BE UTF16LE);

foreach my $to_encoding (@encodings) {
    my $output_file = lc($to_encoding) . "$file_extension";
    my $cmd = "iconv -f $from_encoding -t $to_encoding -o $output_file $input_file";
    system($cmd);
    print $? . "\n";
}

